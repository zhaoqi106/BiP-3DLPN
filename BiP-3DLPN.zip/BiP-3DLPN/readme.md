# BiP-3DLPN: a dual-stage fusion deep learning training framework for rPPG



## File structure

|—— config					    # Training and validation configuration files

​	...

|—— datasets					# Code for reading datasets during the training process

​	...

|—— face_detect				   # Code related to face detection

​	...

|—— nets						# Code related to the BiP3DLPN network model

​	...

|—— preprocessing			      # Code related to dataset preprocessing

​	...

|—— utils					        

​	...

|—— convert_datasets.py		     

|—— evaluate.py

|—— predict.py

|—— train.py





## Datasets

- **RLAP: Remote Learning Affect and Physiologic dataset**

  The Remote Learning Affect and Physiologic (RLAP) dataset is a dataset applied to remote learning affect and engagement, which contains learners' blood volume pulse (BVP) signals that are highly synchronized. This dataset is suitable for training neural rPPG algorithms.

  [KegangWangCCNU/RLAP-dataset: A highly generalizable dataset for training rPPG models (github.com)](https://github.com/KegangWangCCNU/RLAP-dataset)

- **UBFC-rPPG(Univ. Bourgogne Franche-Comté Remote PhotoPlethysmoGraphy)**

  We introduce here a new database called UBFC-rPPG (stands for Univ. Bourgogne Franche-Comté Remote PhotoPlethysmoGraphy) comprising two datasets that are focused specifically on rPPG analysis. The UBFC-RPPG database was created using a custom C++ application for video acquisition with a simple low cost webcam (Logitech C920 HD Pro) at 30fps with a resolution of 640x480 in uncompressed 8-bit RGB format. A CMS50E transmissive pulse oximeter was used to obtain the ground truth PPG data comprising the PPG waveform as well as the PPG heart rates. During the recording, the subject sits in front of the camera (about 1m away from the camera) with his/her face visible. All experiments are conducted indoors with a varying amount of sunlight and indoor illumination. The link to download the complete video dataset is available on request. A basic Matlab implementation can also be provided to read ground truth data acquired with a pulse oximeter.

  [UBFC-rPPG Dataset | Papers With Code](https://paperswithcode.com/dataset/ubfc-rppg)

- **PURE: A Dataset of Public Requirements Documents**

  - Stricker, R., Müller, S., Gross, H.-M.Non-contact "Video-based Pulse Rate Measurement on a Mobile Service Robot" in: Proc. 23st IEEE Int. Symposium on Robot and Human Interactive Communication (Ro-Man 2014), Edinburgh, Scotland, UK, pp. 1056 - 1062, IEEE 2014

- **COHFACE**

  The COHFACE dataset contains RGB video sequences of faces, synchronized with heart-rate and breathing-rate of the recorded subjects.

  [COHFACE — EN (idiap.ch)](https://www.idiap.ch/en/scientific-research/data/cohface) 



## Train

1. Download datasets.

2. Run `convert_datasets.py` to process the dataset into `.hdf5` format files.

3. Modify the configuration file in `config` to adjust the dataset path.

4. Run the `train.py` file.

   
