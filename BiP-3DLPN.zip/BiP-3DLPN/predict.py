import os
from tqdm import tqdm
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from utils.utils import weights_init, get_lr_scheduler, set_optimizer_lr, get_lr
from utils.loss import loss_fn
from datasets.rppg_dataset import RppgDataset
from utils.get_hr import EvaluateHR
import time
import yaml
import numpy as np
from face_detect.face_detect import FaceDetect
from preprocessing.convert_utils import getLocFromVideo, getFaceList, WrapperCap
import cv2
import numpy as np
import os
import matplotlib.pyplot as plt

# 支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
CUDA = torch.cuda.is_available()
if CUDA:
    test_device = 'cuda:0'
else:
    test_device = 'cpu'

def read_video(video_file, video_ts_file, ppg_file, img_size=36):
    fd = FaceDetect(test_device=test_device)
    cap = cv2.VideoCapture(video_file)
    frame_total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))  # 视频总帧数
    # ---------------------------------------------------------------------#
    #   人脸检测，获取最中间的
    # ---------------------------------------------------------------------#
    face_boxes = getLocFromVideo(cap, fd)
    cap.release()
    if len(face_boxes) < frame_total:
        frame_total = len(face_boxes)

    # ---------------------------------------------------------------------#
    #   截取人脸区域
    # ---------------------------------------------------------------------#
    cap = cv2.VideoCapture(video_file)
    raw_video = getFaceList(cap, face_boxes, img_size, frame_total)
    cap.release()

    # ---------------------------------------------------------------------#
    #	读取PPG数据
    # ---------------------------------------------------------------------#
    label = np.loadtxt(ppg_file, dtype=float)
    ppg_data = label[:, 1]
    ppg_ts = label[:, 0]

    # ---------------------------------------------------------------------#
    #	读取视频每一帧时间戳
    # ---------------------------------------------------------------------#
    frame_ts_data = np.loadtxt(video_ts_file, dtype=float)
    frame_ts = frame_ts_data[:, 0]
    frame_ts = np.linspace(frame_ts[0], frame_ts[-1], len(frame_ts))

    fs = len(frame_ts) / (frame_ts[-1] - frame_ts[0])
    print(fs)

    if len(ppg_data) != frame_total:
        ppg_data = np.interp(frame_ts, ppg_ts, ppg_data)
    raw_video[np.isnan(raw_video)] = 0
    ppg_data[np.isnan(ppg_data)] = 0

    return raw_video, ppg_data, fs 

def predict(model, face_video, ppg_data, fs, length=256):
    EvalHR = EvaluateHR(fs=fs)
    EvalHR.clear()
    img_size = face_video.shape[1]
    for i in range(0, len(face_video) - (length + 1), length):
        diff_video = face_video[i+1:i+length+1] - face_video[i:i+length]
        raw_video = (face_video[i+1:i+length+1] + face_video[i:i+length]) / 2
        video_data = np.empty((length, 2, img_size, img_size, 3), dtype=float)
        video_data[:, 0, :, :, :] = raw_video[:, :, :, :]
        video_data[:, 1, :, :, :] = diff_video[:, :, :, :]
        for j in range(3):
            video_data[:, 0, :, :, j] -= np.mean(video_data[:, 0, :, :, j])
            video_data[:, 0, :, :, j] /= np.std(video_data[:, 0, :, :, j])
            video_data[:, 1, :, :, j] -= np.mean(video_data[:, 1, :, :, j])
            video_data[:, 1, :, :, j] /= np.std(video_data[:, 1, :, :, j])
        
        curr_ppg_data = ppg_data[i+1:i+length+1] - ppg_data[i:i+length]
        curr_ppg_data -= np.mean(curr_ppg_data)
        curr_ppg_data /= np.std(curr_ppg_data)
        video_data = torch.tensor(np.transpose(video_data, (0, 1, 4, 2, 3)), dtype=torch.float32).contiguous()
        curr_ppg_data = torch.tensor(curr_ppg_data, dtype=torch.float32)
        if CUDA:
            video_data = video_data.cuda()

        outputs = model(video_data).squeeze()

        outputs = outputs.detach().cpu().numpy().ravel()
        curr_ppg_data = curr_ppg_data.detach().cpu().numpy().ravel()
        EvalHR.add_data(outputs, curr_ppg_data)

    hr_loss = EvalHR.get_loss()
    hr_str = ""
    for key in hr_loss:
        print(f"\t{key}: {hr_loss[key]:.4f}")
        hr_str += f"-{key}[{hr_loss[key]:.4f}]"
    
    pred_signal, real_signal, pred_hr, real_hr = EvalHR.get_result()
    plt.figure()
    plt.plot(real_hr, '--')
    plt.plot(pred_hr, '*')
    plt.show()

if __name__ == '__main__':
    config_file = "config/EVAL_FMFCN.yaml"

    # ---------------------------------------------------------------------#
    #   读取配置文件
    # ---------------------------------------------------------------------#
    with open(config_file, 'r', encoding='utf-8') as f:
        config = yaml.load(f.read(), Loader=yaml.FullLoader)

    # ---------------------------------------------------------------------#
    #   构建模型
    # ---------------------------------------------------------------------#
    model_name = config['MODEL']['NAME']
    if model_name == 'FM_FCN':
        from nets.FM_FCN import FM_FCN
        model = FM_FCN(in_channels=3)
    else:
        raise ValueError(f'不支持{model_name}模型！')
    device = torch.device('cuda:0' if CUDA else 'cpu')
    model.load_state_dict(torch.load(
        config['MODEL']['WEIGHT_PATH'], map_location=device))
    model.eval()
    if CUDA:
        model.cuda()

    video_file = r"H:\datasets\RPPG\vs_rppg\梁成龙\W\005运动后正常/HD Pro Webcam C920_FFV1.avi"
    video_ts_file = r"H:\datasets\RPPG\vs_rppg\梁成龙\W\005运动后正常/HD Pro Webcam C920_timestamp.txt"
    ppg_file = r"H:\datasets\RPPG\vs_rppg\梁成龙\W\005运动后正常/ppg.txt"
    
    raw_video, ppg_data, fs = read_video(video_file, video_ts_file, ppg_file)
    predict(model, raw_video, ppg_data, fs)