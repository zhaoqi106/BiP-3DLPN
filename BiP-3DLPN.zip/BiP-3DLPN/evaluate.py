import os
from tqdm import tqdm
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from utils.utils import weights_init, get_lr_scheduler, set_optimizer_lr, get_lr
from utils.loss import loss_fn
from datasets.rppg_dataset import RppgDataset
from utils.get_hr import EvaluateHR
import time
import yaml
import numpy as np

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
CUDA = torch.cuda.is_available()

device = torch.device('cuda:0' if CUDA else 'cpu')

if __name__ == '__main__':
    config_file = "config/EVAL_BiP3DLPN.yaml"

    # ---------------------------------------------------------------------#
    #   读取配置文件
    # ---------------------------------------------------------------------#
    with open(config_file, 'r', encoding='utf-8') as f:
        config = yaml.load(f.read(), Loader=yaml.FullLoader)

    # ---------------------------------------------------------------------#
    #   构建模型
    # ---------------------------------------------------------------------#
    model_name = config['MODEL']['NAME']
    if model_name == 'FM_FCN_3D':
        from nets.FM_FCN_3D import FM_FCN_3D
        model = FM_FCN_3D(in_channels=3)
    elif model_name == 'FM_FCN_3D_S':
        from nets.FM_FCN_3D_S import FM_FCN_3D_S
        model = FM_FCN_3D_S(in_channels=3)
    elif model_name == 'FM_FCN_3D_YOLO':
        from nets.FM_FCN_3D_YOLO import FM_FCN_3D_YOLO
        model = FM_FCN_3D_YOLO(in_channels=3, out_channels=8)
    elif model_name == 'FM_FCN_3D_YOLO_S1':
        from nets.FM_FCN_3D_YOLO_S1 import FM_FCN_3D_YOLO_S1
        model = FM_FCN_3D_YOLO_S1(in_channels=3, out_channels=8)
    else:
        raise ValueError(f'不支持{model_name}模型！')
    
    model.load_state_dict(torch.load(
        config['MODEL']['WEIGHT_PATH'], map_location=device))
    model.eval()
    model = model.to(device)

    # save_file = config['WORK_PATH'] + '/' + model_name + '_' + config['VAL']['DATA']['NAME'] + \
    #     '-' + str(config['VAL']['DATA']['PREPROCESS']['TIME_LENGTH']) + '.m'

    val_loader_list = []
    for i in range(len(config['VAL']['DATA']['DATA_NAME'])):
        val_dataset = RppgDataset([config['VAL']['DATA']['DATA_PATH'][i]],
                                  config['VAL']['DATA']['PREPROCESS']['IMG_SIZE'],
                                  config['VAL']['DATA']['PREPROCESS']['TIME_LENGTH'],
                                  config['VAL']['DATA']['PREPROCESS']['OVERLAP'],
                                  config['VAL']['DATA']['ST'],
                                  config['VAL']['DATA']['ED'],
                                  False,
                                  config['VAL']['DATA']['PREPROCESS']['MODE'],
                                  diff_norm=config['VAL']['DATA']['PREPROCESS']['DIFF_NORM_METHOD'],
                                  video_norm_per_channel=config['VAL']['DATA']['PREPROCESS']['VIDEO_NORM_PER_CHANNEL'],
                                  eye_mask=config['TRAIN']['DATA']['PREPROCESS']['EYE_MASK'])
        val_loader = DataLoader(val_dataset, shuffle=False, batch_size=config['VAL']['BATCH_SIZE'],
                                num_workers=config['DEVICE']['NUM_WORKERS'], pin_memory=True, drop_last=True)
        val_loader_list.append(val_loader)

    loss_func = loss_fn(config['TRAIN']['LOSS_TYPE'])
    hr_loss = loss_fn('hr_loss')

    model.eval()
    for i in range(len(config['VAL']['DATA']['DATA_NAME'])):
        val_name = config['VAL']['DATA']['DATA_NAME'][i]
        # ---------------------------------------------------------------------#
        #   heart rate evaluator
        # ---------------------------------------------------------------------#
        EvalHR = EvaluateHR(mode=config['TRAIN']['DATA']['PREPROCESS']['MODE'],
                            fs=config['VAL']['DATA']['FS'][i])
        val_epoch_step = len(val_loader_list[i])
        EvalHR.clear()
        val_loss = 0
        _val_curve_loss = 0
        _val_hr_loss = 0
        with tqdm(total=val_epoch_step, desc=f'\t[Valid] {model_name} {val_name}',
                    ncols=150, postfix=dict, mininterval=0.3) as pbar:
            for iteration, batch in enumerate(val_loader_list[i]):
                    videos, labels = batch[0], batch[1]
                    with torch.no_grad():
                        videos = videos.to(device)
                        labels = labels.to(device)
                    
                    outputs = model(videos)
                    loss_value = loss_func(outputs, labels)
                    val_loss += loss_value.item()
                    pbar.set_postfix(**{'loss': val_loss / (iteration + 1)})
                    # ---------------------------------------------------------------------#
                    #   cal heart rate
                    # ---------------------------------------------------------------------#
                    outputs = outputs.detach().cpu().numpy()
                    labels = labels.detach().cpu().numpy()
                    if config['VAL']['BATCH_SIZE'] > 1:
                        for ii in range(len(labels)):
                            EvalHR.add_data(outputs[ii], labels[ii])
                    else:
                        EvalHR.add_data(outputs, labels)

                    # pbar.set_postfix(**{'loss': val_loss / (iteration + 1)})
                    pbar.update(1)
                    # break
        print(f'\t{val_name}\tVal Loss: {val_loss / val_epoch_step:.4f} ')

        # ---------------------------------------------------------------------#
        #   metrics
        # ---------------------------------------------------------------------#
        eval_hr_loss = EvalHR.get_loss()
        hr_str = ""
        for key in eval_hr_loss:
            print(f"\t{key}: {eval_hr_loss[key]:.4f}", end='')
            hr_str += f"-{key}[{eval_hr_loss[key]:.4f}]"
        print(end='\n')


        pred_signal, real_signal, pred_hr, real_hr = EvalHR.get_result()

        save_data = {
            'pred_signal': pred_signal,
            'real_signal': real_signal,
            'pred_hr': pred_hr,
            'real_hr': real_hr,
            'hr_loss': hr_loss
        }
        from scipy.io import savemat
        savemat(model_name + '-' + val_name + '-' + str(
            config['VAL']['DATA']['PREPROCESS']['TIME_LENGTH']) + '-' +config['TRAIN']['DATA']['PREPROCESS']['EYE_MASK'] + '.mat', save_data)
