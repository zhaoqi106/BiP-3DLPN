import torch
from thop import profile
import numpy as np


def autopad(k, p=None, d=1):
    # kernel, padding, dilation
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class SqueezeBlock(torch.nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim
    
    def forward(self, x):
        return x.squeeze(self.dim)

class ConvBlock3D(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=None, groups=1, dialation=1, act=True, bn=True):
        super().__init__()
        self.conv = torch.nn.Conv3d(in_channels, out_channels, kernel_size, stride, autopad(kernel_size, padding, dialation), groups=groups, dilation=dialation, bias=False)
        self.bn = torch.nn.BatchNorm3d(out_channels) if bn is True else torch.nn.Identity()
        self.act = torch.nn.Tanh() if act is True else torch.nn.Identity()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.act(x)
        return x
    
class Bottleneck3D(torch.nn.Module):
    def __init__(self, in_channels, out_channels, shortcut=True, groups=1, kernel_size=(3, 3), e=0.5):
        super().__init__()
        mid_channels = int(out_channels * e)
        self.conv1 = ConvBlock3D(in_channels, mid_channels, kernel_size[0], 1, groups=groups)
        self.conv2 = ConvBlock3D(mid_channels, out_channels, kernel_size[1], 1, groups=groups)
        self.shortcut = shortcut and in_channels == out_channels
    
    def forward(self, x):
        return x + self.conv2(self.conv1(x)) if self.shortcut else self.conv2(self.conv1(x))
    
class C2f3D(torch.nn.Module):
    def __init__(self, in_channels, out_channels, n=1, shortcut=True, groups=1, e=0.5):
        super().__init__()
        self.mid_channels = int(out_channels * e)
        self.conv1 = ConvBlock3D(in_channels, 2 * self.mid_channels, 1, 1)
        self.conv2 = ConvBlock3D((2 + n) * self.mid_channels, out_channels, 1)
        self.ml = torch.nn.ModuleList([Bottleneck3D(self.mid_channels, self.mid_channels, shortcut, groups, kernel_size=((1, 3, 3), (1, 3, 3)), e=1.0) 
                                       for _ in range(n)])
        
    def forward(self, x):
        y = list(self.conv1(x).split((self.mid_channels, self.mid_channels), dim=1))
        y.extend(ml(y[-1]) for ml in self.ml)
        return self.conv2(torch.cat(y, dim=1))
    

class FMBlock(torch.nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.fm_1 = torch.nn.Sequential(
            torch.nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1),
            torch.nn.Tanh()
        )
        self.fm_2 = torch.nn.Sequential(
            torch.nn.Conv1d(out_channels, 1, kernel_size=3, padding=1),
            torch.nn.Flatten()
        )
    
    def forward(self, x):
        x = self.fm_1(x)
        x = self.fm_2(x)
        return x

class BiP3DLPN(torch.nn.Module):
    def __init__(self, in_channels=3, base_channels=16, n_frames=256):
        super().__init__()

        self.coarse_block = ConvBlock3D(in_channels, base_channels, kernel_size=(3, 3, 3), stride=(1, 2, 2))
        self.developing_block = torch.nn.Sequential(
            C2f3D(base_channels, base_channels, n=1, shortcut=True),
            ConvBlock3D(base_channels, base_channels * 2, kernel_size=(3, 3, 3), stride=(1, 2, 2)),
        )
        self.refining_block = torch.nn.Sequential(
            C2f3D(base_channels * 2, base_channels * 2, n=1, shortcut=True),
            ConvBlock3D(base_channels * 2, base_channels * 4, kernel_size=(3, 3, 3), stride=(1, 2, 2)),
            C2f3D(base_channels * 4, base_channels * 4, n=1, shortcut=True)
        )
        self.fine_block = torch.nn.Sequential(
            ConvBlock3D(base_channels * 4, base_channels * 8, kernel_size=(3, 3, 3), stride=(1, 2, 2)),
            C2f3D(base_channels * 8, base_channels * 8, n=1, shortcut=True)
        )
        
        self.filter_block = torch.nn.Sequential(
            torch.nn.AdaptiveAvgPool3d(output_size=(n_frames, 1, 1)),
            SqueezeBlock((-1, -2)),
            FMBlock(base_channels * 8, base_channels * 4)
        )

    def forward(self, x):
        x = self.coarse_block(x)
        x = self.developing_block(x)
        x = self.refining_block(x)
        x = self.fine_block(x)
        x = self.filter_block(x)
        return x
    
if __name__ == '__main__':
    device = torch.device('cpu')
    model = BiP3DLPN(in_channels=3, base_channels=16, n_frames=256).to(device)
    x = torch.randn(4, 3, 256, 36, 36).to(device)
    macs, params = profile(model, inputs=(x,))
    print(f"MACs: {macs}, Params: {params}")
    
    y = model(x)
    print(y.shape)